import borderListStyles from "./border-list-styles.module.css";
import formStyles from "./form-styles.module.css";
import interactiveStyles from "./interactive-styles.module.css";

export { formStyles, borderListStyles, interactiveStyles };
